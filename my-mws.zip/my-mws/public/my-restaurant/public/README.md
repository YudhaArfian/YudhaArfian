# Mobile Web Specialist Certification Course

## 1. Preparations

### 1.1 Local Setup

In preparation to complete stage one of this project, I had to do the following:

1. Fork and clone the [mws-restaurant-stage-1](https://github.com/udacity/mws-restaurant-stage-1) starter repository.
2. Get my own [Mapsbox API key](https://www.mapbox.com/).
3. Get an http server going on localhost. I used [http-server](https://www.npmjs.com/package/http-server), a node-based command-line http-server.

## 2. Normalize Layout

### 2.1 Starting the http-server

I then fired up the server to look at the site in its current state.

```bash
http-server . -p 8000
```

